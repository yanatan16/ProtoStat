<?php
// Prototype Status Web App
// Author: Jon Eisen (jonathan.eisen@ngc.com)
//
// index.php
// Main status page of ProtoStat

// To make a page with the base.php system,
// Me must fill the variables listed in the comments at the top of base.php

// *** Customization Section ***

// Type of system - mdk, pp1, pp2, tp
$system_type = "pp1";

// Webmaster information
$webmaster = "Jon Eisen";
$webmaster_email = "jonathan.eisen@ngc.com"

// Host status script on remote systems
$host_status_script = "./host_status.sh"

// *** End Customization Section ***

// Define Functions
include "functions.php";
include "protostat_functions.php";

// Title and site-wide stuff
$site_title = "ProtoStat";
$tagline = "Query the status of the Prototype Processor";
$author = "Jon Eisen";
$css = "protostat.css";

// Footer
$webmaster_link = "<a href='" . $webmaster_email . "'>". $webmaster . "</a>";
$footline = "This app was developed for for querying the status of the prototype processor." .
		" For questions, please contact the " . $webmaster_link . ".";
$copyright  = "Copyright &copy; Northrop Grumman Electronic Systems 2011";

// Get the host variable as passed in
$host = $_GET["host"];

// Get the list of host names
$system_hosts = get_hosts_from_system($system_type);

// Make the link list
$count = 0;
$menu_links = array();
foreach ($system_hosts as $h)
{
	$link = "/" . make_get_args(array("host",$h));
	if ($host == $h)
	{
		$menu_links[$count++] = "<a href='" . $link . "' class='thispage'>" . $h . "</a>";
	}
	else
	{
		$menu_links[$count++] = "<a href='" . $link . "'>" . $h . "</a>";
	}
}
$menu = get_list_from_array($menu_links);

// Do System Status page or Host Status page?
if (empty($host))
{
	// System status page
	$page_title = "System Status";
	$summary = "This page shows the status of each of this system's hosts.";
	
	//TODO Fill in $content
	//For each host, get its real IP, check if its online, check if its idle
}
elseif (in_array($host, $system_hosts))
{
	// Single Server status page
	$page_title = "Status of " . $host;
	$summary = "This page shows the full status the " . $host . " host.";
	
	//TODO fill in $content
	//For this host, get its real IP, check if its online, check if its idle
	// Also get memory information, reboot information, and any other things
	
	// This will be done via script. 
	// Modify the script on each host to change what is displayed here.
}
else
{
	set_error("Host not in system. Did you mean to go to the <a href='/'>system status page</a>? Check argument or contact the webmaster: " . $webmaster_link);
}

// Include the base html file
if (check_error())
{
	include "base.php" 
}
?>