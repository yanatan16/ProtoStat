<?php
// Prototype Status Web App
// Author: Jon Eisen (jonathan.eisen@ngc.com)
// 
// protostat_functions.php
// ProtoStat-specific function setu

// Function get_hosts_from_system
// Get an array of hosts from a system type
// Note: Possible values are mdk, pp1, pp2, js22, tp
// Parameters: 
//	in	$sys - The system type
// Returns: Array of hosts
function get_hosts_from_system($sys)
{
	switch ($sys)
	{
		case "mdk":
			return array("auxdp", "iadp", "sp1", "sp2", "sp3");
		case "pp1":
			return array("auxdp", "iadp", "sp1", "sp2", "sp3", 
				"cdauxdp", "cdiadp", "sp4", "sp5", "sp6");
		case "pp2":
			return array("auxdp", "iadp", "sp1", "sp2", "sp3");
		case "js22":
			return array("jblade01", "jblade02", "jblade03", "jblade04", "flm1", "flm2", "flm3");
		case "tp":
			return array("auxdp", "iadp", "sp1", "sp2", "sp3", "drex");
		default:
			return null;
	}
}

// Function check_online
// Check whether a server is online
// Parameters: 
//	in	$ip - The IP address for querying the server
//	in	$port - An open port on the server
// Returns: boolean true if the server is online, false if not.
function check_online($ip, $port)
{
	return ($sock = @fsockopen($ip, $port, $num, $error, 5));
}

// Function run_remote_script
// Run a script on a remote host
// Note: The host must have ssh capabilities, and have a no-password rsa key set up for that host.
// Parameters: 
//	in	$ip - The IP address for querying the server
//	in	$user - The username to log in with
// 	in	$script - The script to run on the remote host
//	out	$output - The stdout output of the script
// Returns: The return value of the script
function run_remote_script($ip, $user, $script, $output)
{
	$runstr = "ssh " . $user . "@" . $ip . " " . $script;
	exec($runstr, $output, $ret);
	return $ret;
}

?>